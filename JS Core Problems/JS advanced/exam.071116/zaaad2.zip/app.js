let mapSort = require('./functions');
result.mapSort = mapSort;