let mapSort = require('./help-functions');

result.mapSort = mapSort;