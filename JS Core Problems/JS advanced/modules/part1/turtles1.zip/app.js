import { NinjaTurtle } from './ninjaturtle';
import { EvkodianTurtle } from './evkodianturtle'
import { GalapagosTurtle } from './galapagosturtle'
import { WaterTurtle } from './waterturtle'
import { Turtle } from './turtle'
result.NinjaTurtle=NinjaTurtle;
result.EvkodianTurtle=EvkodianTurtle;
result.GalapagosTurtle=GalapagosTurtle;
result.WaterTurtle=WaterTurtle;
result.Turtle=Turtle;