import {Person} from './people';
import {Post} from './postss'
result.Person = Person;
result.Post = Post;
