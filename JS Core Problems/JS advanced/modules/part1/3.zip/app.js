import {Checkbox} from './checkbox'
import {Numberbox} from './numberbox'
result.Checkbox = Checkbox;
result.Numberbox = Numberbox;
