import { Branch } from './branch';
result.Branch= Branch;
