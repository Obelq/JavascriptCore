import { Branch } from './branch';
import { Employee } from './employee'
result.Branch=Branch;
result.Employee=Employee;